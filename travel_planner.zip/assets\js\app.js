/**
 * Travel Planner Client Script
 */

document.addEventListener('DOMContentLoaded', () => {
    initModals();
    initFilters();
    initItineraryToggles();
});

// Modal Logic
function initModals() {
    const modalTriggers = document.querySelectorAll('[data-modal-target]');
    const modalCloses = document.querySelectorAll('[data-modal-close]');

    modalTriggers.forEach(trigger => {
        trigger.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = trigger.getAttribute('data-modal-target');
            const modal = document.getElementById(targetId);
            if (modal) {
                modal.classList.add('active');
            }
        });
    });

    modalCloses.forEach(closeBtn => {
        closeBtn.addEventListener('click', () => {
            const modal = closeBtn.closest('.modal-overlay');
            if (modal) {
                modal.classList.remove('active');
            }
        });
    });

    document.querySelectorAll('.modal-overlay').forEach(overlay => {
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) {
                overlay.classList.remove('active');
            }
        });
    });
}

// Category / Filter Logic
function initFilters() {
    const filterButtons = document.querySelectorAll('.filter-btn');
    const cards = document.querySelectorAll('.filterable-card');

    if (!filterButtons.length) return;

    filterButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            filterButtons.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            const category = btn.getAttribute('data-category');

            cards.forEach(card => {
                const cardCategory = card.getAttribute('data-category');
                if (category === 'all' || cardCategory === category) {
                    card.style.display = 'flex';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    });
}

// Itinerary Completion Toggle via AJAX
function initItineraryToggles() {
    const toggleCheckboxes = document.querySelectorAll('.itinerary-toggle');
    toggleCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', async () => {
            const itemId = checkbox.getAttribute('data-item-id');
            const isCompleted = checkbox.checked ? 1 : 0;

            const formData = new FormData();
            formData.append('action', 'toggle_itinerary');
            formData.append('item_id', itemId);
            formData.append('completed', isCompleted);

            try {
                const res = await fetch('api.php', {
                    method: 'POST',
                    body: formData
                });
                const data = await res.json();
                if (data.success) {
                    const titleElem = document.getElementById(`item-title-${itemId}`);
                    if (titleElem) {
                        if (isCompleted) {
                            titleElem.style.textDecoration = 'line-through';
                            titleElem.style.opacity = '0.6';
                        } else {
                            titleElem.style.textDecoration = 'none';
                            titleElem.style.opacity = '1';
                        }
                    }
                }
            } catch (err) {
                console.error('Failed to update itinerary item', err);
            }
        });
    });
}

// Pre-fill trip destination modal helper
function planTripForDestination(destId, destName) {
    const modal = document.getElementById('new-trip-modal');
    if (!modal) return;
    
    const destSelect = modal.querySelector('select[name="destination_id"]');
    const titleInput = modal.querySelector('input[name="title"]');
    const locationInput = modal.querySelector('input[name="location"]');

    if (destSelect) destSelect.value = destId;
    if (titleInput) titleInput.value = `Journey to ${destName}`;
    if (locationInput) locationInput.value = destName;

    modal.classList.add('active');
}
